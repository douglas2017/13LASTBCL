/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Codigos;
import java.util.Scanner;



        
/**
 *
 * @author estudiante
 */
public class codigos  {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    double x;
    double y;
                       
               System.out.println("ingrese segunda cantidad"); 
               Scanner D1 = new Scanner (System.in);
               
               x = D1.nextInt();
               y = 15+105;
               System.out.println(y);
    }
    
}
